
from setuptools import setup

with open("README.md","r", encoding = "utf-8") as fh:
    long_description = fh.read()


AUTHOR_NAME = 'Bhavika'
SRC_REPO = 'src'
LIST_of_REQUIREMENTS = ['streamlit']

setup(
    name = SRC_REPO,
    version = '0.0.1',
    author = AUTHOR_NAME,
    description = 'A simple python package for movies recommendation',
    long_description = long_description,
    packages = [SRC_REPO],
    requires = LIST_of_REQUIREMENTS,
    )

